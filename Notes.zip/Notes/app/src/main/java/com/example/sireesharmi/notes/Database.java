package com.example.sireesharmi.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Sireesharmi on 10-11-2016.
 */
public class Database extends SQLiteOpenHelper {


    public static final String dbname="MyNotes.db";
    public static final String id="id";
    public static final String name="name";
    public static final String mynotes="mynotes";
    SQLiteDatabase db;

    public Database(Context context){
        super(context,dbname,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table mynotes"+"("+id+"integer primary key,"+name+" text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         db.execSQL("DROP TABLE IF EXISTS "+mynotes);
         onCreate(db);
    }
    public boolean insertNotes(String name){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        db.insert(mynotes,null,contentValues);
        return true;
    }
    public Cursor getData(int id){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from "+mynotes+" where _id="+id+"",null);
        return cursor;
    }

    public Cursor fetch(){
        Cursor mCursor;
        db=this.getReadableDatabase();
        mCursor=db.query(mynotes,new String[]{"id","name"},null,null,null,null,null);
        if(mCursor!=null)
        {
            mCursor.moveToFirst();
        }
        return mCursor;
        }
}
