package com.example.sireesharmi.notes;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Sireesharmi on 10-11-2016.
 */
public class SeconActivity extends Activity{
    Button save;
    Database db=new Database(this);
    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.view);

        EditText name=(EditText)findViewById(R.id.editname);
        EditText content=(EditText)findViewById(R.id.editname2);
        final String sname=name.getText().toString();

        save=(Button)findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.insertNotes(sname);

            }
        });

    }
}
